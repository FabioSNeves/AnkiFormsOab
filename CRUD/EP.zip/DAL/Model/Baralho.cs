﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Model
{
    public class Baralho
    {
        public int CodBaralho { get; set; }
        public string NomeBaralho { get; set; }
    }
}
